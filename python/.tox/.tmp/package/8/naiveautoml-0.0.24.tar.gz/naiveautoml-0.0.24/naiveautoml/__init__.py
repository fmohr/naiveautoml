from naiveautoml.naiveautoml import NaiveAutoML

__all__ = ["NaiveAutoML"]
__version__ = "0.0.24"
